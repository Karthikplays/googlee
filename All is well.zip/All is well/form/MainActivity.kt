package com.example.registrationform

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val username = findViewById<EditText>(R.id.username)
        val password = findViewById<EditText>(R.id.password)
        val address = findViewById<EditText>(R.id.address)
        val age = findViewById<EditText>(R.id.age)
        val male = findViewById<RadioButton>(R.id.male)
        val female = findViewById<RadioButton>(R.id.female)
        val dob = findViewById<DatePicker>(R.id.dobPicker)
        val stateSpinner = findViewById<Spinner>(R.id.stateSpinner)
        val submitButton = findViewById<Button>(R.id.submitButton)
        val outputText = findViewById<TextView>(R.id.outputText)

        // Spinner values
        val states = arrayOf("Select State", "Telangana", "Andhra Pradesh", "Karnataka", "Tamil Nadu", "Kerala")
        stateSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, states)

        submitButton.setOnClickListener {
            val name = username.text.toString()
            val pass = password.text.toString()
            val addr = address.text.toString()
            val userAge = age.text.toString()
            val gender = if (male.isChecked) "Male" else if (female.isChecked) "Female" else "Not Selected"
            val dobText = "${dob.dayOfMonth}-${dob.month + 1}-${dob.year}"
            val state = stateSpinner.selectedItem.toString()

            val result = """
                Username: $name
                Password: $pass
                Address: $addr
                Gender: $gender
                Age: $userAge
                DOB: $dobText
                State: $state
            """.trimIndent()

            outputText.text = result
        }
    }
}
