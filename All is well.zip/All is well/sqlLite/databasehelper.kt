package com.example.sqliteapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "UserData.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, age INTEGER)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS users")
        onCreate(db)
    }

    fun insertUser(name: String, age: Int): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put("name", name)
        values.put("age", age)
        val result = db.insert("users", null, values)
        return result != -1L
    }

    fun getAllUsers(): String {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM users", null)
        val result = StringBuilder()
        while (cursor.moveToNext()) {
            val name = cursor.getString(1)
            val age = cursor.getInt(2)
            result.append("Name: $name, Age: $age\n")
        }
        cursor.close()
        return result.toString()
    }
}
