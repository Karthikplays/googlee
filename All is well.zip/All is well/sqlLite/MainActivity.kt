package com.example.sqliteapp

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    lateinit var db: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = DatabaseHelper(this)

        val nameInput = findViewById<EditText>(R.id.nameInput)
        val ageInput = findViewById<EditText>(R.id.ageInput)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val showButton = findViewById<Button>(R.id.showButton)

        saveButton.setOnClickListener {
            val name = nameInput.text.toString()
            val age = ageInput.text.toString().toIntOrNull()

            if (name.isNotEmpty() && age != null) {
                val isInserted = db.insertUser(name, age)
                if (isInserted) {
                    Toast.makeText(this, "Data saved!", Toast.LENGTH_SHORT).show()
                    nameInput.text.clear()
                    ageInput.text.clear()
                } else {
                    Toast.makeText(this, "Failed to save!", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter valid data", Toast.LENGTH_SHORT).show()
            }
        }

        showButton.setOnClickListener {
            val result = db.getAllUsers()
            Toast.makeText(this, result.ifEmpty { "No data found." }, Toast.LENGTH_LONG).show()
        }
    }
}
