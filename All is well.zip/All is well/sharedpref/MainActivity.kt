package com.example.sharedprefslogin

import android.content.Context
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameInput = findViewById<EditText>(R.id.usernameInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val loadButton = findViewById<Button>(R.id.loadButton)

        // Save Button Logic
        saveButton.setOnClickListener {
            val username = usernameInput.text.toString()
            val password = passwordInput.text.toString()

            val sharedPrefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            val editor = sharedPrefs.edit()

            editor.putString("username", username)
            editor.putString("password", password)
            editor.apply()

            Toast.makeText(this, "Saved Successfully", Toast.LENGTH_SHORT).show()
        }

        // Load Button Logic
        loadButton.setOnClickListener {
            val sharedPrefs = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            val username = sharedPrefs.getString("username", "No Username")
            val password = sharedPrefs.getString("password", "No Password")

            Toast.makeText(this, "Username: $username\nPassword: $password", Toast.LENGTH_LONG).show()
        }
    }
}
