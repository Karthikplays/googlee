package com.example.batterynotifier

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.widget.Toast

class BatteryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)

        if (level in 0..20) {
            Toast.makeText(context, "Please charge your phone", Toast.LENGTH_LONG).show()
        }
    }
}
