package com.example.toastmessage

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val showInfoButton = findViewById<Button>(R.id.showInfoButton)

        showInfoButton.setOnClickListener {
            val name = "Sai Krishna Siddu"
            val rollNumber = "22XYZ123"

            val message = "Name: $name\nRoll Number: $rollNumber"
            Toast.makeText(this, message, Toast.LENGTH_LONG).show()
        }
    }
}
