package com.example.helloapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. Get the views by their ID
        val nameInput = findViewById<EditText>(R.id.nameInput)
        val okButton = findViewById<Button>(R.id.okButton)
        val outputText = findViewById<TextView>(R.id.outputText)

        // 2. Set what happens when button is clicked
        okButton.setOnClickListener {
            val name = nameInput.text.toString()  // get input text
            outputText.text = "Hello $name"       // display message
        }
    }
}
